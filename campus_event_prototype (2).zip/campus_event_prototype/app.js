// Enhanced campus event alerts prototype with mobile support

const initialAlerts = [
  {id:1, title:'Free Pizza @ Student Union', category:'Food', description:'First 100 students get free slices! 2nd floor.', location:'Student Union - 2nd Floor', time:'Today, 12:30', x:60, y:35, author:'EventsClub', verified:true},
  {id:2, title:'CS101 Study Session', category:'Study', description:'Quick review session before test. Bring questions.', location:'Library Room 204', time:'Today, 15:00', x:30, y:60, author:'PeerTutor', verified:false},
  {id:3, title:'Library Maintenance - Closed', category:'Important', description:'Library closed for 2 hours for maintenance.', location:'Main Library', time:'Today, 09:00 - 11:00', x:45, y:45, author:'CampusAdmin', verified:true},
];

// Load alerts from localStorage or use initial data
let alerts = loadAlerts();

const alertsEl = document.getElementById('alerts');
const filterEl = document.getElementById('filter');
const searchEl = document.getElementById('search');
const postBtn = document.getElementById('postBtn');
const createModal = document.getElementById('createModal');
const detailModal = document.getElementById('detailModal');
const live = document.getElementById('live-region');
const svgMap = document.getElementById('svgMap');
const distanceEl = document.getElementById('distance');
const distanceLabel = document.getElementById('distanceLabel');

// Data persistence functions
function saveAlerts() {
  localStorage.setItem('campusAlerts', JSON.stringify(alerts));
}

function loadAlerts() {
  const saved = localStorage.getItem('campusAlerts');
  if (saved) {
    return JSON.parse(saved);
  }
  return [...initialAlerts];
}

function renderAlerts() {
  const q = (searchEl.value || '').toLowerCase();
  const f = filterEl.value || 'All';
  alertsEl.innerHTML = '';
  const filtered = alerts.filter(a => (f==='All' ? true : a.category===f) && (a.title.toLowerCase().includes(q) || a.description.toLowerCase().includes(q)));
  if(filtered.length===0) {
    alertsEl.innerHTML = '<div class="card">No alerts found. Try changing your search or filters.</div>';
    return;
  }
  filtered.forEach(a => {
    const el = document.createElement('article'); 
    el.className='card'; 
    el.tabIndex=0;
    el.setAttribute('role', 'article');
    el.setAttribute('aria-label', `Event: ${a.title}`);
    
    el.innerHTML = `<h4>${a.title} ${a.verified?'<span class="badge">Verified</span>':''}</h4>
      <div class="meta">
        <span class="category">${a.category}</span>
        <span class="time">${a.time}</span>
        <span class="location">${a.location}</span>
        <span class="author">${a.author}</span>
      </div>
      <p>${a.description}</p>
      <div class="actions">
        <button class="btn-secondary copy" aria-label="Copy event details">📋 Copy</button>
        <button class="btn-secondary view" aria-label="View event details">🔍 View Details</button>
      </div>`;
    
    el.querySelector('.copy').addEventListener('click', (e) => { 
      e.stopPropagation(); 
      navigator.clipboard?.writeText(`${a.title} - ${a.location} - ${a.time} - ${a.description}`); 
      showToast('Event details copied to clipboard!');
    });
    
    el.querySelector('.view').addEventListener('click', (e) => { 
      e.stopPropagation(); 
      openDetail(a); 
    });
    
    el.addEventListener('click', () => openDetail(a));
    el.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        openDetail(a);
      }
    });
    
    alertsEl.appendChild(el);
  });
  renderMapPins();
}

function renderMapPins() {
  // Clear existing pins (except background rect)
  const existing = Array.from(svgMap.querySelectorAll('g.pin')); 
  existing.forEach(n => n.remove());
  
  alerts.forEach(a => {
    const g = document.createElementNS('http://www.w3.org/2000/svg','g'); 
    g.setAttribute('class','pin');
    g.setAttribute('transform',`translate(${a.x}, ${a.y})`);
    g.setAttribute('role', 'button');
    g.setAttribute('tabindex', '0');
    g.setAttribute('aria-label', `Event location: ${a.title}`);
    
    const circ = document.createElementNS('http://www.w3.org/2000/svg','circle'); 
    circ.setAttribute('cx',0); 
    circ.setAttribute('cy',0); 
    circ.setAttribute('r',2);
    circ.setAttribute('fill', a.category==='Food' ? '#f97316' : a.category==='Study' ? '#3b82f6' : '#ef4444');
    circ.setAttribute('stroke','#fff'); 
    circ.setAttribute('stroke-width',0.5);
    
    const title = document.createElementNS('http://www.w3.org/2000/svg','title'); 
    title.textContent = a.title;
    
    g.appendChild(circ); 
    g.appendChild(title);
    
    // Make pins clickable and keyboard accessible
    g.addEventListener('click', () => openDetail(a));
    g.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        openDetail(a);
      }
    });
    
    svgMap.appendChild(g);
  });
}

function openDetail(a){
  document.getElementById('detailTitle').textContent = a.title;
  document.getElementById('detailMeta').textContent = `${a.category} • ${a.time} • ${a.location}`;
  document.getElementById('detailDesc').textContent = a.description;
  document.getElementById('detailAuthor').textContent = a.author;
  detailModal.setAttribute('aria-hidden','false');
  detailModal.style.display='flex';
  
  // Focus the close button for better keyboard navigation
  setTimeout(() => {
    detailModal.querySelector('.close').focus();
  }, 100);
}

function closeDetail(){ 
  detailModal.setAttribute('aria-hidden','true'); 
  detailModal.style.display='none'; 
}

function openCreate(){ 
  createModal.setAttribute('aria-hidden','false'); 
  createModal.style.display='flex'; 
  setTimeout(() => {
    createModal.querySelector('[name=title]').focus();
  }, 100);
}

function closeCreate(){ 
  createModal.setAttribute('aria-hidden','true'); 
  createModal.style.display='none'; 
}

// Mobile-friendly toast notifications
function showToast(message) {
  const toast = document.createElement('div');
  toast.textContent = message;
  toast.style.cssText = `
    position: fixed;
    bottom: 20px;
    left: 50%;
    transform: translateX(-50%);
    background: var(--accent);
    color: white;
    padding: 12px 20px;
    border-radius: 8px;
    z-index: 1001;
    font-size: 14px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    max-width: 90%;
    text-align: center;
  `;
  document.body.appendChild(toast);
  
  setTimeout(() => {
    toast.remove();
  }, 3000);
}

// Form validation enhancement
function setupFormValidation() {
  const titleInput = document.querySelector('[name="title"]');
  const locationInput = document.querySelector('[name="location"]');
  const timeInput = document.querySelector('[name="time"]');
  
  titleInput.addEventListener('input', (e) => {
    if (e.target.value.length < 5) {
      e.target.setCustomValidity('Title must be at least 5 characters');
      e.target.style.borderColor = '#ef4444';
    } else {
      e.target.setCustomValidity('');
      e.target.style.borderColor = '#e2e8f0';
    }
  });
  
  locationInput.addEventListener('input', (e) => {
    if (e.target.value.length < 3) {
      e.target.setCustomValidity('Location must be at least 3 characters');
      e.target.style.borderColor = '#ef4444';
    } else {
      e.target.setCustomValidity('');
      e.target.style.borderColor = '#e2e8f0';
    }
  });
  
  timeInput.addEventListener('input', (e) => {
    if (e.target.value.length < 3) {
      e.target.setCustomValidity('Please provide a valid time description');
      e.target.style.borderColor = '#ef4444';
    } else {
      e.target.setCustomValidity('');
      e.target.style.borderColor = '#e2e8f0';
    }
  });
}

// Debounced search for performance
let searchTimeout;
function setupDebouncedSearch() {
  searchEl.addEventListener('input', () => {
    clearTimeout(searchTimeout);
    searchTimeout = setTimeout(renderAlerts, 300);
  });
}

// Event listeners
filterEl.addEventListener('change', renderAlerts);
searchEl.addEventListener('input', () => {
  clearTimeout(searchTimeout);
  searchTimeout = setTimeout(renderAlerts, 300);
});
postBtn.addEventListener('click', openCreate);
distanceEl.addEventListener('input', () => { 
  distanceLabel.textContent = distanceEl.value + ' km'; 
});

// Radio filter synchronization
document.querySelectorAll('input[name="radpref"]').forEach(radio => {
  radio.addEventListener('change', (e) => {
    filterEl.value = e.target.value;
    renderAlerts();
  });
});

// Form submit
document.getElementById('createForm').addEventListener('submit', (e) => {
  e.preventDefault();
  const fd = new FormData(e.target);
  
  // Final validation
  if (fd.get('title').length < 5) {
    showToast('Error: Title must be at least 5 characters.');
    return;
  }
  
  if (fd.get('location').length < 3) {
    showToast('Error: Location must be at least 3 characters.');
    return;
  }
  
  const newAlert = {
    id: Date.now(),
    title: fd.get('title'),
    category: fd.get('category'),
    description: fd.get('description'),
    location: fd.get('location'),
    time: fd.get('time'),
    x: Math.floor(Math.random()*80)+10,
    y: Math.floor(Math.random()*80)+10,
    author: 'You',
    verified: false
  };
  
  alerts.unshift(newAlert);
  saveAlerts(); // Persist to localStorage
  renderAlerts();
  closeCreate();
  showToast('Alert posted successfully!');
  e.target.reset();
});

// Keyboard shortcut Ctrl/Cmd + N to open form (won't interfere with typing)
window.addEventListener('keydown', (e) => { 
  if ((e.key === 'n' || e.key === 'N') && (e.ctrlKey || e.metaKey)) {
    e.preventDefault();
    if (createModal.getAttribute('aria-hidden') === 'true') {
      openCreate();
    } else {
      closeCreate();
    }
  } 
});

// Modal close handlers
document.querySelectorAll('.modal .close').forEach(btn => {
  btn.addEventListener('click', () => {
    const modal = btn.closest('.modal');
    modal.setAttribute('aria-hidden','true');
    modal.style.display='none';
  });
});

// Close modals when clicking outside
detailModal.addEventListener('click', (e) => { 
  if(e.target === detailModal) closeDetail(); 
});
createModal.addEventListener('click', (e) => { 
  if(e.target === createModal) closeCreate(); 
});

// Close modals with Escape key
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    if (detailModal.getAttribute('aria-hidden') === 'false') {
      closeDetail();
    }
    if (createModal.getAttribute('aria-hidden') === 'false') {
      closeCreate();
    }
  }
});

// Mobile: swipe to close modals (basic implementation)
let touchStartY = 0;
createModal.addEventListener('touchstart', (e) => {
  touchStartY = e.touches[0].clientY;
});

createModal.addEventListener('touchmove', (e) => {
  if (!touchStartY) return;
  
  const touchY = e.touches[0].clientY;
  const diff = touchY - touchStartY;
  
  // If swiping down significantly, close the modal
  if (diff > 100) {
    closeCreate();
    touchStartY = 0;
  }
});

// Initialize the application
function init() {
  renderAlerts();
  setupFormValidation();
  setupDebouncedSearch();
  
  // Sync filter dropdown with radio buttons on page load
  const activeRadio = document.querySelector('input[name="radpref"]:checked');
  if (activeRadio) {
    filterEl.value = activeRadio.value;
  }
  
  // Add viewport meta tag if not present (for older devices)
  if (!document.querySelector('meta[name="viewport"]')) {
    const viewport = document.createElement('meta');
    viewport.name = 'viewport';
    viewport.content = 'width=device-width, initial-scale=1';
    document.head.appendChild(viewport);
  }
}

// Start the app
init();